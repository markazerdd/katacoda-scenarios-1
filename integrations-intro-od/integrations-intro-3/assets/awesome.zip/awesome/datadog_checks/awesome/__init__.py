from .__about__ import __version__
from .check import AwesomeCheck

__all__ = ['__version__', 'AwesomeCheck']
